const faqList = [
  {
    question: 'Apa itu CodeIn?',
    answer: 'loren insum',
  },
  {
    question: 'Bagaimana cara melakukan pendaftaran akun di CodeIn?',
    answer: 'loren insum',
  },
  {
    question: 'Bagaimana cara membuat pertanyaan di CodeIn?',
    answer: 'loren insum',
  },
  {
    question: 'Bagaimana cara menjawab di CodeIn?',
    answer: 'loren insum',
  },
  {
    question: 'Apa yang dimaksud dengan Fitur Tag?',
    answer: 'loren insum',
  },
];

export { faqList };
